Flask-HTTPAuth
--------------

Basic and Digest HTTP authentication for Flask routes.


