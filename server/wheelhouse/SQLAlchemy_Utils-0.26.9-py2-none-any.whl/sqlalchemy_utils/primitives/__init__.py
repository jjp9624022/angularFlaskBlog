from .weekday import WeekDay
from .weekdays import WeekDays


__all__ = (
    WeekDay,
    WeekDays
)
